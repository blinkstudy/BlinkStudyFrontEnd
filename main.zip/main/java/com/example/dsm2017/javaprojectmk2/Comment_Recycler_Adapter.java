package com.example.dsm2017.javaprojectmk2;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;

public class Comment_Recycler_Adapter extends RecyclerView.Adapter<Comment_Recycler_Adapter.mViewHolder>
{
    private ArrayList <Comment_Contact> arrayList;
    private RecyclerViewClickListener mListener;
    public interface RecyclerViewClickListener {
        //아이템 클릭
        void onItemClicked(int position, Comment_Contact contact);
        }

        public Comment_Recycler_Adapter(ArrayList<Comment_Contact> row_InfoArrayList)
        {
            this.arrayList = row_InfoArrayList;
        }

        public void setmListener(RecyclerViewClickListener mListener)
        {
            this.mListener = mListener;
        }

        public void addItem(Comment_Contact contact)
        {
            //추가
            arrayList.add(contact);
            //어느 위치의 아이템이 삽입되었는지를 통지
            notifyItemInserted(arrayList.size());
            //어느 위치의 데이터가 변경되었는지 통지
            notifyItemChanged(arrayList.size());
        }

        public void removeItem(int position)
        {
            //삭제
            arrayList.remove(position);
            //어느 위치의 아이템이 삭제되었는지 통지
            notifyItemRemoved(position);
            //첫번째 파라미터와 두번째 파라미터 사이의 데이터가 변경되었음을 통지
            //하나를 삭제하면 위에 있는 아이템이 하나씩 앞으로 오도록 함
            notifyItemRangeChanged(position, arrayList.size());
        }

        @Override
        public mViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
        {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.comment_recyclerview,parent,false);
            return new mViewHolder(view);
        }

        @Override
        public void onBindViewHolder(mViewHolder holder, int position)
        {
            Comment_Contact contact = arrayList.get(position);
            holder.mtex_name.setText(contact.getUser());
            holder.mtex_comment.setText(contact.getComment());

            if(mListener != null)
            {
                final int pos = position;
                final Comment_Contact con = contact;
                holder.itemView.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v) {
                        mListener.onItemClicked(pos,con);
                    }
                });
            }
        }
        @Override
        public int getItemCount()
        {
            return arrayList.size();
        }

        public static class mViewHolder extends RecyclerView.ViewHolder
        {
            TextView mtex_name;
            TextView mtex_comment;
            public mViewHolder(View itemView)
            {
                super(itemView);
                mtex_name = itemView.findViewById(R.id.m_tex_name);
                mtex_comment = itemView.findViewById(R.id.m_tex_comment);
            }
        }
    }