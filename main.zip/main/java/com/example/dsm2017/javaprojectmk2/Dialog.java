package com.example.dsm2017.javaprojectmk2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class Dialog extends AppCompatActivity {
    private EditText edt_user, edt_comment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog);
        edt_user = findViewById(R.id.edt_user)
        ;edt_comment = findViewById(R.id.edt_comment);
        findViewById(R.id.btn_yes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = edt_user.getText().toString();
                String comment = edt_comment.getText().toString();
                Intent intent = new Intent();
                intent.putExtra("User",user);
                intent.putExtra("Comment",comment);
                setResult(RESULT_OK,intent);
                Log.d("Data1",user + " / " + comment);
                finish();
            }
        });
    }
}