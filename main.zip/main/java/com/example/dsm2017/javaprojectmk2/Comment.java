package com.example.dsm2017.javaprojectmk2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;

public class Comment extends AppCompatActivity {
    private TextView tex_title, tex_notice;
    private Button btn_comment;
    private RecyclerView comment_recyclerView;
    private ArrayList<Comment_Contact> arrayList;
    private Comment_Recycler_Adapter adapter;
    private LinearLayoutManager comment_layoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);

        tex_title = findViewById(R.id.tex_title);
        tex_notice = findViewById(R.id.tex_notice);
        btn_comment = findViewById(R.id.btn_comment);
        comment_recyclerView = (RecyclerView) findViewById(R.id.commentRecyclerView);

        comment_layoutManager = (LinearLayoutManager) new LinearLayoutManager(getApplicationContext());
        comment_recyclerView.setLayoutManager(comment_layoutManager);

        arrayList = new ArrayList<Comment_Contact>();
        arrayList.add(new Comment_Contact("User","Comment"));

        adapter = new Comment_Recycler_Adapter(arrayList);
        comment_recyclerView.setAdapter(adapter);

        btn_comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {Intent intent = new Intent(getApplicationContext(), Dialog.class);
            startActivityForResult(intent,2000);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {if(requestCode == 2000 && resultCode == RESULT_OK && data != null) {
        String title = data.getStringExtra("User");
        String comment = data.getStringExtra("Comment");
        Log.d("Data2",title + " / " + comment);adapter.addItem(new Comment_Contact(title,comment));
        comment_recyclerView.smoothScrollToPosition(adapter.getItemCount());
    }
    }
}
