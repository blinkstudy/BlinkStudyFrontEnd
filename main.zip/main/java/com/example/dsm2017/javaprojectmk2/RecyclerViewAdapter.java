package com.example.dsm2017.javaprojectmk2;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private ArrayList<Contact> Row_InfoArrayList;
    private RecyclerViewClickListener mListener;

    public interface RecyclerViewClickListener {
        //아이템 클릭
        void onItemClicked(int position, Contact contact);
    }

    public RecyclerViewAdapter(ArrayList<Contact> row_InfoArrayList) {
        this.Row_InfoArrayList = row_InfoArrayList;
    }

    public void setmListener(RecyclerViewClickListener mListener) {
        this.mListener = mListener;
    }

    public void addItem(Contact contact) { //추가
        Row_InfoArrayList.add(contact);

        //어느 위치의 아이템이 삽입되었는지를 통지
        notifyItemInserted(Row_InfoArrayList.size());

        //어느 위치의 데이터가 변경되었는지 통지
        notifyItemChanged(Row_InfoArrayList.size());
    }

    public void removeItem(int position) { //삭제
        Row_InfoArrayList.remove(position);
        //어느 위치의 아이템이 삭제되었는지 통지
        notifyItemRemoved(position);
        //첫번째 파라미터와 두번째 파라미터 사이의 데이터가 변경되었음을 통지
        //하나를 삭제하면 위에 있는 아이템이 하나씩 앞으로 오도록 함
        notifyItemRangeChanged(position, Row_InfoArrayList.size());
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recyclerview,parent,false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Contact contact = Row_InfoArrayList.get(position);
        holder.tv_title.setText(contact.getTitle());
        holder.tv_content.setText(contact.getContent());

        if(mListener != null) {
            final int pos = position;
            final Contact mcon = contact;

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.onItemClicked(pos,mcon);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return Row_InfoArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView tv_title;
        TextView tv_content;

        public ViewHolder(View itemView) {
            super(itemView);
            tv_title = itemView.findViewById(R.id.tv_title);
            tv_content = itemView.findViewById(R.id.tv_content);
        }
    }
}
