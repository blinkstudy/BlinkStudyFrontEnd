package com.example.dsm2017.teamproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        TextView tex_Title = findViewById(R.id.tex_Title);
        TextView tex_Content = findViewById(R.id.tex_Content);
        TextView tex_Type = findViewById(R.id.tex_Type);

        Intent intent = getIntent();

            String title=intent.getExtras().getString("Title");
            String content=intent.getExtras().getString("Content");
            String type = intent.getExtras().getString("Type");

            tex_Title.setText(title);
            tex_Content.setText(content);
            tex_Type.setText(type);


    }
}
